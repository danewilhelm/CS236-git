#include "../project5/Interpreter.h"
#include "Node.h"
#include "Graph.h"

#include <iostream>

void test_node_to_string() {
    Node node;
    node.addEdge(4);
    node.addEdge(8);
    node.addEdge(2);
    cout << node.toString() << endl;
}

void test_graph_to_string() {
    Graph graph(3);
    graph.addEdge(1,2);
    graph.addEdge(1,0);
    graph.addEdge(0,1);
    graph.addEdge(1,1);
    cout << graph.toString();
}

void  test_interpreter_make_graph() {

    // predicate names for fake rules
    // first is name for head predicate
    // second is names for body predicates
    pair<string,vector<string>> ruleNames[] = {
            { "A", { "B", "C" } },
            { "B", { "A", "D" } },
            { "B", { "B" } },
            { "E", { "F", "G" } },
            { "E", { "E", "F" } },
    };

    vector<Rule> rules;

    for (auto& rulePair : ruleNames) {
        string headName = rulePair.first;
        Predicate headPredicate(headName, {});

        vector<string> bodyNames = rulePair.second;
        vector<Predicate> bodyPredicates;
        for (auto& bodyName : bodyNames) {
            Predicate bodyPredicate(bodyName, {});
            bodyPredicates.push_back(bodyPredicate);
        }
        Rule generatedRule(headPredicate, bodyPredicates);
        rules.push_back(generatedRule);
    }

    Graph graph = Interpreter::makeGraph(rules);
    cout << graph.toString();
}




int main(int argc, char* argv[]) {
//    test_node_to_string();
//    test_graph_to_string();
    test_interpreter_make_graph();
}