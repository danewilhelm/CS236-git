#include <set>
#include <string>
#include <sstream>


using namespace std;
#pragma once

class Node {

private:

    set<int> adjacentNodeIDs;
    // You may want add other variables to your Node class later, perhaps a visited flag or a post-order number

public:

    void addEdge(int adjacentNodeID) {
        adjacentNodeIDs.insert(adjacentNodeID);
    }

    string toString() {
        stringstream out;
        size_t loop_counter = 0;
        for (int node_ID : adjacentNodeIDs) {
            out << "R" << node_ID;
            if (loop_counter + 1 < adjacentNodeIDs.size()) {
                out << ",";
            }
            loop_counter++;
        }
        return out.str();
    }

};