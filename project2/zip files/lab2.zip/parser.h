#include "../project1/Token.h"
//#include "../project1/.h"
#include <iostream>
#include <vector>


using namespace std;

class Parser {
    private:
        vector<Token> tokens;
    public:
//---------------constructor------------------------------------//
        Parser(const vector<Token>& tokens) : tokens(tokens) {}

//---------------main parser functions-------------------------//

    void idList() {
        if (tokenType() == COMMA) {
            match(COMMA);
            match(ID);
            idList();
        } else {
            // lambda
        }
    }

    void scheme() {
        // Grammar Rule
            // scheme -> ID LEFT_PAREN ID idList RIGHT_PAREN
        if (tokenType() == ID) {
            match(ID);
            match(LEFT_PAREN);
            match(ID);
            idList();
            match(RIGHT_PAREN);
        }
    }


//---------------helper functions------------------------------//

        TokenType tokenType() const {
            return tokens.at(0).get_token_type();
        }

        void advanceToken() {
            tokens.erase(tokens.begin());
        }

        void throwError() {
            cout << "error" << endl;
        }

        void match(TokenType t) {
            cout << "match: " << t << endl;
            // if the current token type matches t
            if (tokenType() == t) {
                // advance to the next token
                advanceToken();
            } else {
                // report a syntax error
                throwError();
            }
        }

};

